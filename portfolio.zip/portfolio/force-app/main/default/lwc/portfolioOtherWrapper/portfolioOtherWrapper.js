import { api, LightningElement, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import AWARDS from '@salesforce/schema/Portfolio__c.Awards__c';
import SUPERBADGES from '@salesforce/schema/Portfolio__c.SuperBadges__c';
import LANGUAGES from '@salesforce/schema/Portfolio__c.Other_languages__c';
import PortfolioAssets from '@salesforce/resourceUrl/PortfolioAssets';
export default class PortfolioOtherWrapper extends LightningElement {

    trophy = `${PortfolioAssets}/PortfolioAssets/trophy.png`;
    badge = `${PortfolioAssets}/PortfolioAssets/badge.png`;
    language = `${PortfolioAssets}/PortfolioAssets/language.png`;

    
    @api recordId;
    awards=[];
    superBadges=[];
    languages=[];

    @wire(getRecord,{
        recordId: '$recordId',
        fields: [AWARDS,SUPERBADGES,LANGUAGES]
    })
    otherDetailsList({data,error})
    {
        if(data)
        {
            console.log(JSON.stringify(data));
            this.formatData(data);
        }
         if(error)
        {
            console.error(error);
        }
    }

    formatData(data)
    {
        const{Awards__c,Other_languages__c,SuperBadges__c} = data.fields;
        this.awards = Awards__c?Awards__c.value.split(','):[]
        this.superBadges = SuperBadges__c?SuperBadges__c.value.split(';'):[]
        this.languages = Other_languages__c?Other_languages__c.value.split(','):[]
    }

}