import { api, LightningElement } from 'lwc';

export default class PortfolioUserDetailsAndStatsWrapper extends LightningElement {
   
   
    @api recordId
    @api objectApiName
    @api badge
    @api points 
    @api trails
    @api trailheadRank
    @api resumeUrl;

}