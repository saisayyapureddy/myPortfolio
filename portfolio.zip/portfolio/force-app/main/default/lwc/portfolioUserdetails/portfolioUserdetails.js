import { LightningElement,api } from 'lwc';

export default class PortfolioUserdetails extends LightningElement {
    @api recordId
    @api objectApiName

    @api resumeUrl;

    downloadHandler(){
        
        window.open(this.resumeUrl, '_blank');
    }

    //'https://github.com/saisayyapureddy/sai-Resume/raw/main/SFdummyResume%20(1).pdf';
}