import { api, LightningElement } from 'lwc';

import WEATHER_ICONS from '@salesforce/resourceUrl/weatherAppIcons'
export default class WeatherResultCard extends LightningElement {

  clearIcon = WEATHER_ICONS+'/weatherAppIcons/clear.svg'
  cloudIcon = WEATHER_ICONS+'/weatherAppIcons/cloud.svg'
  dropletIcon = WEATHER_ICONS+'/weatherAppIcons/droplet.svg'
  hazeIcon = WEATHER_ICONS+'/weatherAppIcons/haze.svg'
  mapIcon = WEATHER_ICONS+'/weatherAppIcons/map.svg'
  rainIcon = WEATHER_ICONS+'/weatherAppIcons/rain.svg'
  snowIcon = WEATHER_ICONS+'/weatherAppIcons/snow.svg'
  stormIcon = WEATHER_ICONS+'/weatherAppIcons/storm.svg'
  thermometerIcon = WEATHER_ICONS+'/weatherAppIcons/thermometer.svg'
  arrowBackIcon = WEATHER_ICONS+'/weatherAppIcons/arrow-back.svg'


    @api weatherData;  // The data passed from parent component
    response;
    weatherIcon;
    error;

    connectedCallback() {
        console.log('Data in childCmp', this.weatherData);
        this.formatData(this.weatherData);
    }

    goBack() {
        this.weatherIcon='';
        // Dispatching custom event to go back
        const eve = new CustomEvent('goback');
        this.dispatchEvent(eve);
    }

    formatData(info) {

        /*
        console.log("inputData: " + inputData);
        // Check if inputData is already an object. If it's a string, parse it.
        if (typeof inputData === 'string') {
            // If inputData is a JSON string, parse it
            try {
                this.result = JSON.parse(inputData);
            } catch (error) {
                console.error("Error parsing JSON", error);
                this.error = "Invalid JSON format";
            }
        } else if (typeof inputData === 'object') {
            // If it's already an object, just assign it
            this.result = inputData;
        }

        // Log the object for debugging purposes
        console.log("Formatted data:", this.result);
        console.log(JSON.parse(JSON.stringify(this.result)));

        */  


      const city = info.name
      const country = info.sys.country
      const {description, id} = info.weather[0]
      const {temp, feels_like, humidity} = info.main
      if(id === 800){
        this.weatherIcon = this.clearIcon
      } else if((id>=200 && id <=232) || (id>=600 && id <=622)){
        this.weatherIcon = this.stormIcon
      } else if(id>=701 && id <=781){
        this.weatherIcon = this.hazeIcon
      } else if(id>=801 && id <=804){
        this.weatherIcon = this.cloudIcon
      } else if((id>=500 && id <=531) || (id>=300 && id<= 321)){
        this.weatherIcon = this.rainIcon
      } else {}

      this.response = {
        city: city,
        temperature:Math.floor(temp),
        description:description,
        location:`${city}, ${country}`,
        feels_like: Math.floor(feels_like),
        humidity:`${humidity}%`
      }
       
    }
}
