import { LightningElement } from 'lwc';

export default class SimpleIntrestCalculator extends LightningElement {

    principal = 0;  // Default to 0, so we have a value
    rate = 0;  // Default to 0
    selectedOne;
    options = [
        {
            label: 'Per Year',
            value: 'Y'
        },
        {
            label: 'Per Month',
            value: 'M'
        }
    ];
    term = 1;  // Default to 1, so we have a value
    showResult = false;
    interest = 0;
    total = 0;

    handlePrincipalChange(event) {
        this.principal = parseFloat(event.target.value);
        console.log('Principal amount', this.principal);
        this.showResult = false;
    }

    handleRateChange(event) {
        this.rate = parseFloat(event.target.value);
        console.log('Rate of interest', this.rate);
        this.showResult = false;
    }

    termChange(event) {
        this.term = parseFloat(event.target.value);
        console.log('Term', this.term);
        this.showResult = false;
    }

    comboHandler(event) {
        if (event.target.value === 'M') {
            this.selectedOne = 'month';
            console.log('Selected one', this.selectedOne);
        } else {
            this.selectedOne = 'year';
            console.log('Selected one', this.selectedOne);
        }
        this.showResult = false;
    }

    calculateInterest() {
        this.showResult = true;

        // Validate inputs before performing calculations
        if (!this.principal || !this.rate || !this.term) {
            console.log('Please provide all values');
            return;
        }

        // Calculate interest based on the selection (month/year)
        let calculatedInterest;
        if (this.selectedOne === 'month') {
            calculatedInterest = this.principal * (this.rate / 100) * this.term;
        } else {
            calculatedInterest = this.principal * (this.rate / 100) * this.term * (12) ;
        }

        this.interest = calculatedInterest;

        // Total = Principal + Interest (Ensure both are numbers for proper addition)
        this.total = this.principal + this.interest;

        // Format interest and total with commas and decimals
        this.interest = this.formatCurrency(this.interest);
        this.total = this.formatCurrency(this.total);
        console.log('total aft', this.total);
    }

    formatCurrency(amount) {
        return `$${Number(amount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`;
    }

    get resultByselctedOption() {
        return this.selectedOne === 'month' ? true : false;
    }
}
