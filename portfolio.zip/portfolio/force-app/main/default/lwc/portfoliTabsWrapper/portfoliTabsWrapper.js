import { api, LightningElement } from 'lwc';

export default class PortfoliTabsWrapper extends LightningElement {
    @api recordId;
    @api objectApiName;
}