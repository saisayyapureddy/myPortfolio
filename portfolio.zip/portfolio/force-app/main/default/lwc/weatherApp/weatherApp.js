import { LightningElement, track } from 'lwc';


import getWeatherDetails from '@salesforce/apex/WeatherController.getWeatherDetails';
export default class WeatherApp extends LightningElement {
    @track city = '';
    isError = false;
    result = null;
    loadingText = '';
    showResult=false;

    // Dynamic style for loading/error messages
    get LoadingTextStyle() {
        return this.isError ? 'error-msg' : 'success-msg';
    }

    inputHandler(event) {
        this.city = event.target.value;
        this.loadingText='';
    }

    submitHandler(event) {
        this.loadingText = 'Fetching data...';
        this.isError = false;  // Reset error flag
        event.preventDefault();
        this.fetchData();
    }

    fetchData() {

        //client side call
        /*
        const endPoint = `https://api.openweathermap.org/data/2.5/weather?q=${this.city}&units=metric&appid=${API_KEY}`;
        console.log(endPoint, 'endPoint');

        fetch(endPoint)
            .then((res) => {
                // if (!res.ok) {
                //     throw new Error('Network response was not ok');
                // }
                // Wait for the response to be converted to JSON
                this.loadingText ='';
                return res.json(); // Return the promise from res.json()
            })
            .then((data) => {
                console.log("data is ",data); // Log the parsed data
                this.finalData(data); // Process the data
            })
            .catch((err) => {
                console.error('Error:', err.message); // Handle the error and log it
                this.isError = true; // Set error flag to true
                this.loadingText = 'Something went wrong, please try again'; // Show a user-friendly error message
            });

         */  

        // server side call
        getWeatherDetails({ input: this.city })
           .then(data => {
                console.log("data from server ",data); // Log the parsed data
                this.finalData(JSON.parse(data)); // Process the data
                
            })
           .catch(error => {
                console.error('Error:', error.message); // Handle the error and log it
                this.isError = true; // Set error flag to true
                this.loadingText = 'Something went wrong, please try again'; // Show a user-friendly error message
            });

    }

    finalData(data) {
        if (data.cod === '404') {
            this.isError = true; // Set error flag when city is not found
            this.result = null;
            this.showResult = false;
            this.loadingText = `${this.city} is not found`; // Display a specific message
            console.log('City not found');
        } else {
            this.showResult=true; //
            this.result = data; // Store the weather data
            this.loadingText = ''; // Clear loading text when data is found
        }
    }

    goBackInParent(){
        this.showResult=false; //
        this.city=''; // reset city input
        this.loadingText=''; // reset loading text
        this.result=null; // reset weather data
        this.isError=false; // reset error flag
        
    }
}