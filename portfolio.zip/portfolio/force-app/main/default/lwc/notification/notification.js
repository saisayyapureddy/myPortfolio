import { api, LightningElement } from 'lwc';

export default class Notification extends LightningElement {
    showToastMessage=false;
    message 
    
    get correctVariant() {
        const variant_color = this.variant === 'success' ? 'success' :
                              this.variant === 'error' ? 'error' :
                              this.variant === 'warning' ? 'warning' :
                              'info';  // Default variant if none of the conditions match
        
        return `slds-notify slds-notify_toast slds-theme_${variant_color}`;
    }
    

    @api showToast(message,variant){
        this.message=message || 'Please enter a message';
        this.variant=variant || 'success';
        //set timeout
        this.showToastMessage = true;
        setTimeout(() => {
            this.showToastMessage = false;
        }, 3000);
        
    }
}