import { LightningElement, wire } from 'lwc';
import createNote from '@salesforce/apex/NoteController.createNote';
import getNotes from '@salesforce/apex/NoteController.getNotes';
import updateNotes from '@salesforce/apex/NoteController.updateNote';
import {refreshApex} from '@salesforce/apex';
import LightningConfirm from 'lightning/confirm';
import deleteNote from '@salesforce/apex/NoteController.deleteNote';

export default class NoteTakingApp extends LightningElement {
    // Default note record
    DEFAULT_NOTE_FORM = {
        Name: "",
        Note_Description__c: ""
    };

    notesArray = [];
    selectedRecordId;

    // Initial state
    noteRecord = { ...this.DEFAULT_NOTE_FORM };
    showModal = false;
    wiredResult;
    formats = [
        'font', 'size', 'bold', 'italic', 'underline', 'strike', 'list',
        'indent', 'align', 'link', 'clean', 'table', 'header', 'color',
    ];

    // Fetch notes data from Salesforce
    @wire(getNotes)
    notesList(result) {
        this.wiredResult = result;
        const{data,error} = this.wiredResult;
        if(data) {
            this.notesArray = data.map((item) => {
                // Format the date to a readable format
                let formatedDate = new Date(item.LastModifiedDate).toDateString();
                // Return the note with the formatted date
                return {...item, formatedDate};
            });
        }
        console.log(JSON.stringify(this.notesArray));
        if(error) {
            console.error('Error fetching notes: ', error);
            this.showToastMessage(error.message.body, "error");
        }
    }

    // Get to validate the form before enabling the Save button
    get validateInput() {
        return !(this.noteRecord.Name && this.noteRecord.Note_Description__c);
    }

    get modalName(){
        return this.selectedRecordId? 'Update note' : 'Add Note';
    }

    // Handle input changes
    inputChangeHandler(event) {
        const { name, value } = event.target;
        this.noteRecord = { ...this.noteRecord, [name]: value };
    }

    // Open the modal
    createNoteHandler() {
        this.showModal = true;
    }

    // Close the modal and reset form
    closeModal() {
        this.showModal = false;
        this.resetForm();
        this.selectedRecordId = null;
    }

    // Reset the form
    resetForm() {
        this.noteRecord = { ...this.DEFAULT_NOTE_FORM };
    }

    // Submit the form
    submitHandler(event) {
        event.preventDefault();
        console.log('form details: ' + JSON.stringify(this.noteRecord));

        if(this.selectedRecordId){
            this.updateRecord(this.selectedRecordId);
        }
        else{
            this.insertNote();
        }
    
    }

    // Insert note into Salesforce
    insertNote() {
        console.log('Inserting note with:', this.noteRecord);  // Debugging log
        createNote({ title: this.noteRecord.Name, description: this.noteRecord.Note_Description__c })
            .then(() => {
                console.log('Note created successfully');
                this.closeModal();
                this.selectedRecordId = null;
                this.refresh();
                this.showToastMessage("Note created successfully!!", "success");
            })
            .catch(error => {
                console.error('Error creating note: ', error.message.body);
                this.showToastMessage(error.message.body, "error");
            });
    }

    // Show Toast notification
    showToastMessage(message, variant) {
        const note = this.template.querySelector('c-notification');
        if (note) {
            note.showToast(message, variant);
        }
    }

    editHandler(event)
    {
        //spelling both are correctin html and javascript in html data-recordid  
        const {recordid} = event.target.dataset;
        const selectedRecord = this.notesArray.find(record => record.Id === recordid); 
       
        this.selectedRecordId = selectedRecord.Id; 
        console.log('selected record',this.selectedRecordId);
        // Reset the form to edit the selected record
        this.noteRecord={   
            Name: selectedRecord.Name,
            Note_Description__c:selectedRecord.Note_Description__c
        }
        this.showModal = true;  
    }

    updateRecord(record){
        console.log('Updating record:', record);  // Debugging log
        updateNotes({recordId :record,title:this.noteRecord.Name,description:this.noteRecord.Note_Description__c})
           .then(() => {
                console.log('Note updated successfully');
                this.selectedRecordId = null;
                this.closeModal();
                this.refresh();  // Refresh the notes list after updating the record to reflect the changes immediately.
                this.showToastMessage("Note updated successfully!!", "success");
            })
           .catch(error => {
                console.error('Error updating note: ', error.message.body);
                this.showToastMessage(error.message.body, "error");
            });
    }

    refresh()
    {
        return refreshApex(this.wiredResult);
    }
    deleteNoteHandler(event){
        const {recordid} = event.target.dataset;
        this.selectedRecordId = recordid;
        this.handelConfirm();
    }
    async handelConfirm(){
       const result =  await LightningConfirm.open({
            title: 'Delete Note',
            message: 'Are you sure you want to delete this note?',
            confirmLabel: 'Delete',
            cancelLabel: 'Cancel',
            actions: [
                { label: 'Delete', style: 'destructive' },
                { label: 'Cancel' }
            ]
        })
        if(result)
        {
            this.deleteNotes();
        }
        else{
            this.selectedRecordId = null;
        }  // Close the modal and reset selectedRecordId if user cancels the delete operation.
    }
    deleteNotes()
    {
        deleteNote({recordId: this.selectedRecordId}).then(() => {
            console.log('Note deleted successfully');
            this.selectedRecordId = null;
            this.refresh();  // Refresh the notes list after deleting the record to reflect the changes immediately.
            this.showToastMessage("Note deleted successfully!!", "success");
        }).catch((error) => {
            console.error('Error deleting note: ', error.message.body);
            this.showToastMessage(error.message.body, "error");
            this.selectedRecordId = null;
            
        })
    }

}
