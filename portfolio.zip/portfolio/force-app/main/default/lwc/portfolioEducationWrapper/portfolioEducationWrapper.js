import { api, LightningElement, wire } from 'lwc';
import { getRelatedListRecords } from 'lightning/uiRelatedListApi';

export default class PortfolioEducationWrapper extends LightningElement {
    @api recordId;
    educationData=[]

    columns = [
        {
            label: 'Education',
            fieldName: 'title',
            type: 'text'
        },
        {
            label: 'Institution Name',
            fieldName: 'institute',
            type: 'text'
        },
        {
            label: 'Passing Year',
            fieldName: 'passingYear',
            type: 'text'
        },
    ];

    // Wire the getRelatedListRecords method
    @wire(getRelatedListRecords, {
        parentRecordId: '$recordId',
        relatedListId : 'Educations__r', // Ensure this is the correct API name for the related list
        fields: ['Education__c.Institute__c', 'Education__c.Title__c', 'Education__c.Passing_Year__c'],
        sortBy: 'Education__c.Passing_Year__c' // Should be a single field, not an array
    })
    educationRecordsList({ data, error }) {
        if (data) {
            //console.log(JSON.stringify(data)); // Log the data returned from the wire service
            this.formatData(data);
        }

        if (error) {
            // Log more error details for debugging
            console.error('Error in fetching related records:', JSON.stringify(error));
            
        }
    }

    formatData(data)
    {
       this.educationData =  data.records.map((item) => {
            let ID = item.id 
            const{Institute__c,Passing_Year__c,Title__c} = item.fields;
            let institute = Institute__c?Institute__c.value:null;
            let passingYear = Passing_Year__c?Passing_Year__c.value:null;   
            let title = Title__c?Title__c.value:null;

            return {
                ID,institute,passingYear,title
            }
        })
        console.log(JSON.stringify(this.educationData));  // Log the formatted data
    }

}
