import { LightningElement } from 'lwc';

import PortfolioAssets from '@salesforce/resourceUrl/PortfolioAssets';
import INTREST_CALCULATOR  from '@salesforce/resourceUrl/intrestCalculator';
export default class PortfolioProjectsWrapper extends LightningElement {

    BMICalculator = `${PortfolioAssets}/PortfolioAssets/Projects/BMICalculator.png`
    CurrencyCalculator = `${PortfolioAssets}/PortfolioAssets/Projects/CurrencyCalculator.png`
    WeatherApp = `${PortfolioAssets}/PortfolioAssets/Projects/WeatherApp.png`
    SurveyApp = `${PortfolioAssets}/PortfolioAssets/Projects/Survey.png`
    NoteApp = `${PortfolioAssets}/PortfolioAssets/Projects/NoteTakingApp.png`
    intrest_calc= INTREST_CALCULATOR;


    projects=[
        {
            title: 'BMI Calculator',
            link:'https://sai-portfolio-dev-ed.develop.my.site.com/bmi-calculator',
            image: this.BMICalculator
        },
        {
            title: 'Currency Converter',
            link:'https://sai-portfolio-dev-ed.develop.my.site.com/currency-converter',
            image: this.CurrencyCalculator
        },
        {
            title: 'Weather App',
            link:'https://sai-portfolio-dev-ed.develop.my.site.com/weather-app',
            image: this.WeatherApp
        },
        {
            title: 'Survey App',
            link:'https://sai-portfolio-dev-ed.develop.my.site.com/surveys/survey/runtimeApp.app?invitationId=0KidM0000000vUX&surveyName=employee_survey&UUID=dce81813-ac44-4d64-87ea-b6a790197be4',
            image: this.SurveyApp
        },
        {
            title: 'Note Taking App',
            link:'https://sai-portfolio-dev-ed.develop.my.site.com/note-taking-app',
            image: this.NoteApp
        },

        {
            title: 'Intrest calculator App',
            link:'https://sai-portfolio-dev-ed.develop.my.site.com/simple-intrest-calculator',
            image: this.intrest_calc
        }
    ]









}