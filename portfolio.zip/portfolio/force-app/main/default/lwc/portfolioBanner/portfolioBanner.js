import { LightningElement,wire,api } from 'lwc';
import PortfolioAssets from '@salesforce/resourceUrl/PortfolioAssets';
import { getRecord,getFieldValue } from 'lightning/uiRecordApi';
import FULLNAME from '@salesforce/schema/Portfolio__c.Full_Name__c';
import COMPANY_NAME from '@salesforce/schema/Portfolio__c.Company__c';
import COMPANY_LOCATION from '@salesforce/schema/Portfolio__c.Company_location__c';
import DESIGNATION from '@salesforce/schema/Portfolio__c.Designation__c';

import BANNERIMG from '@salesforce/resourceUrl/profile_modified';

export default class PortfolioBanner extends LightningElement {

    @api  recordId       //='a04dM000001AbH3QAK';
    @api  linkedinUrl    //= 'https://www.linkedin.com/in/sai-sayyapureddy/'
    @api  twitterUrl    // = 'https://x.com/SayyapureddySai'
    @api  githubUrl     // = 'https://github.com/saisayyapureddy'
    @api  youtubeUrl    // = 'https://youtube.com/salesforcetroop'
    @api  trailheadUrl  // = 'https://www.salesforce.com/trailblazer/saisayyapureddy4043'
    @api  blogUrl       //= 'https://www.salesforcetroop.com/'

    userPic = `${PortfolioAssets}/PortfolioAssets/userPic.jpeg`
    linkedin = `${PortfolioAssets}/PortfolioAssets/Social/linkedin.svg`
    youtube = `${PortfolioAssets}/PortfolioAssets/Social/youtube.svg`
    github = `${PortfolioAssets}/PortfolioAssets/Social/github.svg`
    twitter = `${PortfolioAssets}/PortfolioAssets/Social/twitter.svg`
    trailhead = `${PortfolioAssets}/PortfolioAssets/Social/trailhead1.svg`
    blog = `${PortfolioAssets}/PortfolioAssets/Social/blogger.svg`

    bannerImg =BANNERIMG;


    fullName
    companyName
    companyLocation
    designation
    

    
    @wire(getRecord,{
        recordId: '$recordId',
        fields: [FULLNAME, COMPANY_NAME,COMPANY_LOCATION,DESIGNATION]
    })
    wiredRecord({ data, error }) {
        if(data) {
            this.fullName = getFieldValue(data, FULLNAME);
            this.companyName = getFieldValue(data, COMPANY_NAME);
            this.companyLocation = getFieldValue(data, COMPANY_LOCATION);
            this.designation = getFieldValue(data, DESIGNATION);
        } else if (error) {
            console.error('Error in fetching record data:', error);
        }
    }


    


}