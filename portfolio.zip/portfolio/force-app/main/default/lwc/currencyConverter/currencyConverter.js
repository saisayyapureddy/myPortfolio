import { LightningElement } from 'lwc';
import {countryCodeList} from 'c/countryCodeList';
import currencyConverterAssets from '@salesforce/resourceUrl/currencyConverterAssets';
export default class CurrencyConverter extends LightningElement {

    currencyConverterImg = currencyConverterAssets+'/currencyConverterAssets/currency.svg';
    COUNTRYCODELIST = countryCodeList;

    countryFrom = "USD"; // default value
    countryTo = "EUR";   // default value
    amount ;          // default value
    result;
    error;
   
    // Handle change for combobox or any input
    handleChange(event) {
        this.result = '';  // Reset the result field on any change
        this.error = '';  // Reset the error message on any change
        const { name, value } = event.target;

        // Efficiently update the property based on the combobox's name
        if (name === "CountryFrom") {
            this.countryFrom = value;
        } else if (name === "CountryTo") {
            this.countryTo = value;
        } else if (name === "amount") {
            this.amount = value;
        }

        // Log the values for debugging purposes
        console.log('countryFrom:', this.countryFrom);
        console.log('countryTo:', this.countryTo);
        console.log('amount:', this.amount);
    }

     
    submitHandler(event)
    {
        event.preventDefault();
        this.convert();
    }

    async convert()
    {
        const enteredAmount = Number(this.amount);
        const ACCESS_KEY = '63fab1729571db6e57ef587915ce9eaf';
        //const countryfrom = this.countryFrom;
        //const countryto = this.countryTo;
        const API_URL = `https://api.exchangerate.host/convert?access_key=${ACCESS_KEY}&from=${this.countryFrom}&to=${this.countryTo}&amount=${enteredAmount}`;
        console.log('API URL:', API_URL);
        try {
            const response = await fetch(API_URL);
            if (!response.ok) {
                throw new Error('API call failed with status: ' + response.status);
            }

            const jsonData = await response.json();
            console.log('Response:', jsonData);

            if (jsonData.error) {
                throw new Error(jsonData.error.info);  // If the API returns an error
            }

            this.result = jsonData.result;
        } catch (error) {
            this.error = error.message;
            console.log('Error:', error);
        }
    }
}