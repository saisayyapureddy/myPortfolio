import { api, LightningElement } from 'lwc';

export default class PortfolioStringToHtmlConverter extends LightningElement {

    @api htmlString
    show =false;

    renderedCallback()
    {
        if(this.show){
            return
        }
         this.appendHtml(this.htmlString)
        
    }

    appendHtml(html){
        let div = this.template.querySelector('.htmlConverter');
        if(div){
            div.innerHTML = html;
            this.show = true;
        }
        
    }
}