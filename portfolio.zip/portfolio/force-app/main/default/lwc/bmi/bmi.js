import { LightningElement } from 'lwc';

export default class Bmi extends LightningElement {

    height='';
    weight='';
    bmiValue='';
    result

    inputHandler(event){    
    const{name,value} =event.target;

        if(name === 'height')
        {
            this.height = value;
        }
        if(name === 'weight')
        {
            this.weight = value;
        }
    }
    submitHandler(event)
    {
        event.preventDefault();
        console.log('height: ' + this.height + ' weight: ' + this.weight);
        this.calculate();
    }
    calculate()
    {
        let height = Number(this.height)/100;
        let bmi = Number(this.weight)/(height*height);
        console.log('Bmi is ' + bmi);
        this.bmiValue = Number(bmi.toFixed(2));
        if(bmi < 18.5){
            this.result = 'Underweight';
        }
        else if(bmi >= 18.5 && bmi < 25){
            this.result = 'Healthy';
        }
        else if(bmi >= 25 && bmi < 30){
            this.result = 'Overweight';
        }
        else{
            this.result = 'Obese';
        }

        console.log('Value: ' + this.bmiValue);
        console.log('Result is'+ this.result);
    }
    recalculatorHandler()
    {
        this.height='';
        this.weight='';
        this.bmiValue='';
        this.result='';
        console.log('Recalculated');
    }
}
